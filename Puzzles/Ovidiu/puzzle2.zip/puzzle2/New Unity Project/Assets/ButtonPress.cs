using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class ButtonPress : MonoBehaviour
{
    public static event Action<string> SendButtonValue = delegate { };

    public void ButtonClicked()
    {
        Debug.Log("Clicked " + gameObject.name.Substring(gameObject.name.IndexOf("_") + 1));
        SendButtonValue(gameObject.name.Substring(gameObject.name.IndexOf("_") + 1));
    }

    private void OnMouseDown()
    {
        ButtonClicked();
    }
}
