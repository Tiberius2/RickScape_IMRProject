using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class ScreenBehaviour : MonoBehaviour
{
    private string correctSequence;
    private string currentSequence;

    public Material WrongMaterial;
    public Material RightMaterial;
    public Material BaseMaterial;

    void Start()
    {
        ButtonPress.SendButtonValue += AddValueAndCheckSequence;
        correctSequence = GenerateSequence();
        Debug.Log(correctSequence);
        currentSequence = "";
    }

    private void OnDestroy()
    {
        ButtonPress.SendButtonValue -= AddValueAndCheckSequence;
    }

    private void AddValueAndCheckSequence(string buttonInput)
    {
        StartCoroutine(Aux(buttonInput));
    }

    private IEnumerator Aux(string buttonInput)
    {
        int element = int.Parse(buttonInput);
        currentSequence += element;

        Debug.Log("currentSequence: " + currentSequence);

        if (currentSequence != correctSequence.Substring(0, currentSequence.Length))
        {
            currentSequence = "";
            yield return StartCoroutine(FlashColour(WrongMaterial, 2));
        }
        else if (currentSequence == correctSequence)
        {
            currentSequence = "";
            yield return StartCoroutine(FlashColour(RightMaterial, 2));
            correctSequence = GenerateSequence();
            Debug.Log("New correct sequence: " + correctSequence);
        }
    }

    private string GenerateSequence()
    {
        System.Random r;
        string sequence = "";

        for (int i = 0; i < 4; ++i)
        {
            r = new System.Random();
            sequence += r.Next(1, 10).ToString();
        }
        return sequence;
    }

    private IEnumerator FlashColour(Material material, int time)
    {
        gameObject.GetComponent<Renderer>().material = material;
        yield return StartCoroutine(ResetMaterial(time));
    }

    private IEnumerator ResetMaterial(float time)
    {
        yield return new WaitForSeconds(time);
        gameObject.GetComponent<Renderer>().material = BaseMaterial;
    }
}